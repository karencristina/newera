<!DOCTYPE html>
<html lang="pt-BR">
    
<?php 
$title='Tecnologia';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">


            <article>

                <div class="col-md-6 col-sm-6 padd-box">

                   <a href="./materia-macbook.php"> <img src="img/Apple.jpg" class="img-responsive" alt="novo mackbook pró da apple"></a>

                    <a href="./materia-macbook.php"><h1 class="title-tec">Novo Mac Book Pró <span class="colortitulo">vai te surpreender.</span></h1></a>






                </div>
             

                <div class="col-md-3 col-sm-3  padd-box ">

                    <section class="border-ron">
    <a href="./materia-microsoftlumia.php"><img src="img/lumia.jpg" class="img-responsive" alt="microsoft lança novo lumia"></a> 

                    <a href="./materia-microsoftlumia.php"><h2 class="title-ron blackpainel">Microsoft lança novo Lumia.</h2></a>

                    </section>
                    
                    <section>
  <a href="./materia-novoiphone.php"><img src="img/iphone6s.jpg" class="img-responsive" alt="confira o novo iphone 6s"></a>

                    <a href="./materia-novoiphone.php"><h2 class="title-ron blackpainel">Confira o novo IPhone 6S.</h2></a>

                    </section>
                    
                

                </div>
                
                
                
                <div class="col-md-3 col-sm-3  padd-box ">

                    <section class="border-ron">
<a href="./materia-intelprocessador.php"><img src="img/intel.jpg" class="img-responsive" alt="intel inicia vendas de novo processador"></a>   

                    <a href="./materia-intelprocessador.php"><h2 class="title-ron blackpainel">Intel inicia vendas de novo processador.</h2></a>

                    </section>
                    
                    <section>
 <a href="./materia-nvidiamelhor.php"><img src="img/nvidia.jpg" class="img-responsive" alt="nvidia fala que é melhor que outras empresas"></a>

                    <a href="./materia-nvidiamelhor.php"><h2 class="title-ron blackpainel">Nvidia fala "Somos melhores que outros".</h2></a>

                    </section>
                    
                

                </div>
                
                 
                
              

            </article>



        </div>
 

 
        <div class="row">
        
       <div class="col-md-12 padd-box">
            
             
           <section>
              
            <a href="./celular.php"><h2 class="text-center color-tec2 border-tec2 text-ajustepc tx">Celular</h2></a>
             
               
            <div class="col-md-4 col-sm-4 padd-box">
               
              <section class="bordered">

                 <a href="./materia-motorola.php"><img src="img/motox.jpg" class="img-responsive" alt="motorola anuncia novo moto x"></a> 
                        <a href="./materia-motorola.php"><h2 class="txt-notice text-center">Motorola anuncia versão comemorativa do Moto-X para 2016</h2></a>

                </section>
            
            </div>
               
            
             <div class="col-md-4 col-sm-4 padd-box">
               
               <section class="bordered" id="boxtec6">

                     <a href="./materia-sansung.php">   <img src="img/s6gold.jpg" class="img-responsive" alt="samsung confirma versão gold de galaxy s6"></a>
                        <a href="./materia-sansung.php"><h2 class="txt-notice text-center">Samsung confirma versão gold de galaxy s6 confira o preço</h2></a>

                    </section>
            
            </div>   
               
               
                <div class="col-md-4 col-sm-4 padd-box">
                    
                    <section class="bordered" id="boxtec1">

                     <a href="./materia-sonyanuncia.php"><img src="img/z3.jpg" class="img-responsive" alt="Sony anuncia novos Z3"></a> 
                        <a href="./materia-sonyanuncia.php"><h2 class="txt-notice text-center">Sony anuncia sua nova linha de smartphones Z3 </h2></a>

                    </section>
            
            </div>   
              
          
                  


                 
            
          </section>
        
        
        
        </div>
        
           
         
            
        </div> 
         
        
        
        <div class="row">

            <section>

               <a href="./pc.php"> <h2 class="text-center color-tec2 border-tec2 tx text-ajustepc">PC</h2></a>

                <div class="col-md-3 col-sm-3 padd-box">
                  
                      <section class="bordered box-ajust">

                       <a href="./materia-window.php"><img src="img/win10.jpg" class="img-responsive" alt="microsoft tentou instalar windows 10 a força"></a> 
                        <a href="./materia-window.php"><h2 class="txt-notice text-center">Microsoft adimite ter tentado instalar Windows 10 a força</h2></a>

                </section>

                  


                </div>
                
                  <div class="col-md-3 col-sm-3 padd-box">


                    <section class="bordered box-ajust">

                       <a href="./materia-dell.php"><img src="img/delxps.jpg" class="img-responsive" alt="Dell xps13 chega com novo processador"></a>
                        <a href="./materia-dell.php"><h2 class="txt-notice text-center">Dell XPS 13 chega com processador Intel Skylake</h2></a>

                    </section>


                </div>
                
                  <div class="col-md-3 col-sm-3 padd-box">

                         
              <section class="bordered">

                    <a href="./materia-appleafirma.php"><img src="img/appletim.jpg" class="img-responsive" alt="apple afirma que seus clientes são mais felizes"></a>
                        <a href="./materia-appleafirma.php"><h2 class="txt-notice text-center">Apple afirma "Nossos clientes são mais  felizes" entenda o motivo</h2></a>

                </section>
            



                </div>
                
                  <div class="col-md-3 col-sm-3 padd-box">


                    <section class="bordered" id="boxtec7">

                    <a href="./materia-amd.php"><img src="img/amd.jpg" class="img-responsive" alt="amd anuncia novos processadores caterpillar"></a>    
                        <a href="./materia-amd.php"><h2 class="txt-notice text-center">AMD revela sua nova linha de processadores Caterpillar</h2></a>

                    </section>


                </div>

 
            </section>
    


        </div>
        
    


        <?php
        include './includes/footer.php';
        ?> 

    </div>


 

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
</body>

</html>
  

