<!DOCTYPE html>
<html lang="pt-BR">
    
<?php 
$title='Sobre';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        
            
            
        
            
            
          
        <div class="row">

            <article>
            <h1 class="border-contato color-contato">Entre em contato</h1>
              
                  <div class="col-md-8 col-md-push-2">
                      
		       		<form role="form">
					
					  <div class="form-group">
                          <label>Nome</label>
                           <input type="text" class="form-control"  placeholder="Nome" required="required">
					    
					  </div>

					  <div class="form-group">
                          <label>E-mail</label>
					    <div class="input-group">
					     <div class="input-group-addon">@</div>
					    <input class="form-control" type="email" placeholder="email@email.com" required="required">
					    </div>
					  </div>

					  <div class="form-group">
                          <label>Assunto</label>
					    <input type="text" class="form-control" placeholder="Assunto" required="required">  
					  </div>				 
                       
                      <div  class="form-group">
                        
                          <label>Menssagem</label>
					  <textarea class="form-control" rows="3" style="resize: none; height: 270px;" placeholder="Mensagem: " required="required"></textarea> <br>
					  <button class="btn btn-contato">Enviar</button> 
                    
                       </div>    
                       
					</form>

		        </div>
           
               

            
            
            
            </article>
        
        </div>
        
               
            
       <?php
        include './includes/footer.php';
        ?> 

  
           

        </div>
     

 




    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
</body>

</html>
  

