<!DOCTYPE html>
<html lang="pt-BR">
    
    <?php
$title='Saúde';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">


            
            
            
            <article>
                <h2 class="text-center color-estar border-estar border-sub-saude">Saúde</h2>
                   
                <div class="col-md-6 col-sm-12   padd-box">

                    <a href="materia-yoga.php"> <img src="img/yoga.jpg" class="img-responsive" alt="yoga para praticar">

                    <h1 class="title-h1">Praticar yoga diariamente auxilia no equilibrio emocional</h1></a>






                </div>
             

                <div class="col-md-6 col-sm-12  padd-box ">

                  
                    <a href="materia-dieta.php"> <img src="img/vegetariano.jpg" class="img-responsive" alt="Vegetariano">

                   <h1 class="title-h1">Dieta vegetariana- Opções de ingredientes saudáveis</h1></a>




                </div>
      

            </article>
            

        </div>
 

 
        <div class="row">
        
    
                       
        </div> 
         

        
        <div class="row">
            


            <section>

                <h2 class="text-center color-estar border-estar border-sub-saude">Outros destaques</h2>

                <div class="col-md-4 col-sm-4 padd-box">


                    <section class="bordered">

                         <a href="materia-cafe.php"><img src="img/cafe.jpg" class="img-responsive" alt="Café da manhã">
                        <h2 class="txt-notice text-center">Conheça os benefícios de um café da manhã rico em proteínas</h2></a>

                    </section>


                </div>

            
                <div class="col-md-4 col-sm-4 padd-box">


                    <section class="bordered">

                       <a href="materia-animais.php"> <img src="img/animais-de-estimaca.jpg" class="img-responsive" alt="animais">
                       <h2 class="txt-notice text-center">A companhia de animais faz bem aos doentes com Alzheimer e Parkinson</h2></a>

                    </section>


                </div>

                
                
     <div class="col-md-4 col-sm-4 padd-box ">


                    <section class="bordered">

                       <a href="materia-espinha.php"> <img src="img/espinha.jpg" class="img-responsive" alt="...">
                        <h2 class="txt-notice text-center">Método infalível para esconder espinhas, vem aprender com a gente!</h2></a>

                    </section>


                    
                </div>
              

                
            </section>




        </div>
                
                
                
              <?php
        include './includes/footer.php';
        ?> 

    </div>


    <script src="./js/jquery-1.11.0.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
        
</body>

</html>    
   