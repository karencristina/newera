<!DOCTYPE html>
<html lang="pt-BR">
    
    <?php
$title='Normas';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">

            

            
            
            <article>

                <div class="mat col-md-12 col-sm-12   padd-box">
                    
                    <h1 class="text-materia-2">Termo de Uso do Portal New Era</h1>
                    
                    <p class="materias">Este Termo regulamenta o uso do Portal NEW ERA, bem como os serviços/produtos neste oferecidos e fornecidos pelo NEW ERA NETWORKS BRASIL S.A., pessoa jurídica com sede na cidade de São Paulo, na Av. Nações Unidas, nº. 12.901, 12º Andar - Torre Norte, inscrita no CNPJ sob o nº 91.088.328/0001-67, aos usuários de Internet.
A utilização do Portal por você implica na aceitação integral e plena deste Termo e Política de Privacidade. Deste modo, é importante que você o leia com atenção.</p>
                        
<p class="materias">A utilização do Portal também se submete aos demais termos, avisos, regulamentos de uso e instruções disponibilizados ao usuário, bem como às eventuais atualizações realizadas neste Termo. Deste modo, é imprescindível que você fique atento às atualizações disponibilizadas no Portal.</p>
                    
<h3>2. Condições de acesso e utilização do portal</h3>
                    
<p>Para navegar no Portal, não lhe será exigido a realização de cadastro. Você terá acesso ao seu próprio NEW ERA pelo celular, computador ou tablet, com conteúdos específicos baseados em escolhas de navegação. Você também poderá acessar o Portal fazendo login por diversas contas, inclusive, por suas contas do Facebook ou Google Plus, o que lhe possibilitará o acesso a informações e serviços de forma integrada e interativa. Neste caso, não se esqueça que, independente da conta escolhida para o acesso, o login e senha de acesso são pessoais e de sua responsabilidade. Por isso, é importante que você os mantenha sob sigilo.</p>
<p class="materias">Se você fizer mau uso do Portal, infringindo leis, disposições deste Termo de Uso ou da Política de Privacidade, o NEW ERA poderá suspender ou mesmo interromper os serviços prestados a você. Para melhor se orientar, visite, no Portal, a tabela de práticas admitidas e de práticas não aceitas pelo NEW ERA.</p>
<p class="materias">A utilização do Portal ou dos Serviços não lhe permite reproduzir, copiar, distribuir, permitir o acesso público, transformar e/ou modificar os conteúdos deste, a menos que possua a prévia autorização do titular dos correspondentes direitos ou que o faça com permissão legal. Não há, por meio do uso do Portal ou dos serviços, qualquer transferência ou conferência de propriedade intelectual sob o conteúdo acessado.
O Portal New Era e seus Serviços não exibe a você apenas conteúdos próprios, mas também de terceiros parceiros. Os conteúdos disponibilizados por terceiros são de reponsabilidade destes. Assim, se o NEW ERA detectar nestes conteúdos qualquer conteúdo ilícito ou em contrariedade ao seu Termo de Uso ou Política de Privacidade ficará a seu critério a remoção de determinado conteúdo e a notificação às autoridades competentes.
O Portal NEW ERA permite uma rica interação com as diversas redes sociais, permitindo a você que compartilhe conteúdos e informações de seu interesse. Todavia, é importante lembrar que ao acessar ícones ou links disponibilizados no Portal, você estará sujeito aos Termos de Uso e Política de Privacidade vinculada ao site acessado. O NEW ERA recomenda que você os leia com atenção para garantir uso informado e consciente dos serviços disponibilizados.</p>
<p class="materias">Se você for criança[1] ou adolescente[2] ou compartilhar o computador com pessoas nestas condições, lembre-se que, para navegar no Portal NEW ERA, estas pessoas precisam de permissão ou supervisão dos pais ou responsáveis legais durante a navegação. O NEW ERA também oferece o serviço “New Era Antivírus Família”, que pode possibilitar uma navegação adequada às crianças e aos adolescentes. Verifique maiores detalhes 
[1] Pessoa com até 12 (doze) anos de idade incompletos (art.2º, da Lei nº 8.069/90). 
[2] Pessoa de 12 a 18 anos (art.2º, da Lei nº 8.069/90).</p>
<h3>3. Das responsabilidades</h3>
<p class="materias">O NEW ERA disponibilizará o seu Portal de modo a sempre oferecer serviços de qualidade, sendo que quaisquer interrupções na prestação destes serviços, em razão de ocorrências técnicas, operacionais ou imprevisíveis em razão da natureza do serviço oferecido, serão solucionadas de maneira célere e efetiva possível. Caso tenha qualquer problema na utilização de nossos serviços, não deixe de contatar nossa central de relacionamento.
O NEW ERA concede a terceiros parceiros espaço para publicação de anúncios, por isso, é de responsabilidade destes os conteúdos veiculados.
O Portal possui ainda dispositivos técnicos denominados “links de acesso”, tais como banners, botões, diretórios e ferramentas de busca que permitem aos usuários ter acesso a páginas pertencentes a terceiros. Assim, você deve estar ciente que, ao clicar em um destes “links de acesso”, será direcionado a páginas externas e que não são de titularidade do NEW ERA, motivo pelo qual não garantimos nem assumimos qualquer tipo de responsabilidade pelos danos e prejuízos de qualquer natureza que possam decorrer do acesso a estas páginas ou dos conteúdos ali disponibilizados.
O NEW ERA poderá disponibilizar em seu Portal ou produtos espaços interativos para comentários dos internautas. Os conteúdos publicados por assinantes ou visitantes nos produtos interativos é de inteira responsabilidade de quem os publicou, não havendo qualquer revisão ou fiscalização pelo NEW ERA nos referidos conteúdos. Caso você identifique algum conteúdo ofensivo disponibilizado no Portal ou nos Serviços, comunique ao NEW ERA, por meio do endereço eletrônico abuse@newera.com.br.</p>
<h3>4. Segurança</h3>
<p class="materias">O NEW ERA preza pela segurança, sigilo e inviolabilidade de todos os dados cadastrais fornecidos por você. No entanto, você deve estar ciente que as medidas de segurança na Internet não são infalíveis, principalmente em razão da rápida evolução do ambiente virtual. Deste modo, o NEW ERA não se responsabiliza por danos e/ou prejuízos decorrentes de caso fortuito ou força maior.
No mais, para que você saiba como o NEW ERA trata seus dados pessoais e protege a sua privacidade quando você acessa o Portal e os serviços neste disponibilizados, sugere-se a leitura da Política de Privacidade do NEW ERA.</p>
<h3>5. Uso indevido do portal NEW ERA</h3>
<p class="materias">Se durante a utilização do Portal ou de qualquer serviço, você constatar a ocorrência de alguma atividade ilícita, contrária a este Termo, à Política de Privacidade do NEW ERA, a preceitos éticos ou ofensiva, poderá enviar uma comunicação ao NEW ERA por meio do endereço abuse@newera.com.br contendo os seguintes dados:</p>
<p class="materias">(a) dados pessoais: nome, endereço, número de telefone e endereço de correio eletrônico;</p>
<p class="materias">(b) especificação da suposta atividade ilícita ocorrida no Portal e, em particular, quando se tratar de suposta violação de direitos autorais, indicação precisa e completa dos conteúdos protegidos e supostamente infringidos;</p>
<p class="materias">(c) fatos e/ou circunstâncias que revelam o caráter ilícito de tal atividade;</p>
<p class="materias">(d) declaração expressa e clara de que a utilização dos conteúdos foi realizada sem o consentimento do titular dos direitos de propriedade intelectual supostamente infringidos.</p>
<p class="materias">O NEW ERA se reserva o direito de remover, sob seu exclusivo critério, sempre que possuir condições técnicas para tanto e a qualquer momento, todo conteúdo ofensivo, contrário à Lei, a este Termo, à Política de Privacidade, às Condições Particulares de certos Serviços e demais avisos, regulamentos de uso e instruções disponibilizados no Portal e/ou Serviços, independente da anuência do usuário ou terceiro que o publicou.</p>
<h3>6. Sobre estes termos</h3>
<p class="materias">Para se adaptar às expectativas dos usuários, o NEW ERA poderá modificar este Termo de Uso. Assim, é importante que você o consulte regularmente e caso não concorde com as alterações promovidas, entre em contato com nossos canais de relacionamento ou descontinue o uso do seu serviço.</p>
<h3>7. Da comunicação do NEW ERA com o usuário</h3>
<p class="materias">As notificações e comunicações do NEW ERA a você serão preferencialmente realizadas por meio de e-mail. As comunicações, igualmente, poderão ser realizadas das seguintes formas:</p>
<p class="materias">(a) envio de carta ao domicílio do usuário quando este tiver fornecido um endereço válido ao NEW ERA;</p>
<p class="materias">(b) comunicação telefônica ao número fornecido pelo Usuário;</p>
<p class="materias">(c) mediante publicação de mensagens relacionadas aos Serviços prestados pelo NEW ERA no Portal;</p>
<p class="materias">(d) mediante mensagens SMS ao celular fornecido pelo usuário.
As comunicações e notificações serão realizadas por meio dos dados informados por você e consideradas efetivas, sendo imprescindível, para tanto, que você mantenha seus dados atualizados.</p>
<h3>8. Duração da prestação de serviços</h3>
<p class="materias">O Portal e os demais Serviços tem duração indeterminada, estando facultado ao NEW ERA extingui-los, suspendê-los ou interrompê-los a qualquer momento.</p>
<h3>9. Lei aplicável e eleição de foro</h3>
<p class="materias">Todos os itens deste Termo de Uso são regidos pelas leis vigentes no ordenamento jurídico brasileiro. Para todos os assuntos referentes à interpretação, ao cumprimento ou qualquer outro questionamento relacionado a este Termo de Uso, as partes concordam em se submeter ao Foro da Comarca de São Paulo, com exceção de reclamações apresentadas por usuários que se enquadrem no conceito legal de consumidores, que poderão submeter tais reclamações ao foro de seu domicílio.</p>
<p class="materias">Para qualquer sugestão ou proposta de colaboração, escreva ao endereço editorial@newera.com.br.</p>




                </div>
             

                    

            </article>
            

    
                       
        </div> 
         

            
   

        <?php
        include './includes/footer.php';
        ?> 

    </div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
 
    
</body>

</html>