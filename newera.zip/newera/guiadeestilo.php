<!DOCTYPE html>
<html lang="pt-BR">
    
<?php 
$title='Guia de estilo';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">


            
            
            <article>

                <div class="text-moda col-md-4 col-sm-4   padd-box">
                    

                    
                    <a href="materia-estampas.php"><img src="img/fendas.jpg" class="img-responsive" alt="cores">

                    <a href="materia-estampas.php"><h1 class=" title-h1-carros blackpainel-tr-karen-tendencia ">Estampas injetam cores e frescor aos looks no verão. Confira dicas </h1></a>






                </div>
             

                <div class="text-moda col-md-4 col-sm-4  padd-box ">

                  
                    <a href="materia-rosa.php"><img src="img/batomvermelho.jpg" class="img-responsive" alt="cores">

                    <a href="materia-rosa.php"><h1 class="title-h1-carros blackpainel-tr-karen-tendencia">Do pálido ao pink: Rosa tinge as passarelas e o visual no dia-a-dia </h1></a>




                </div>
      
    <div class="text-moda col-md-4 col-sm-4  padd-box ">

                  
                    <a href="materia-jeans.php"><img src="img/jeans.jpg" class="img-responsive" alt="cores">

                    <a href="materia-jeans.php"><h1 class="title-h1-carros blackpainel-tr-karen-tendencia">Jeans é peça fundamental no guarda-roupas feminino </h1></a>




                </div>
            </article>



        </div>
 


      
    <div class="row">
                
            
   
            
<section>

                <div class="col-md-6 col-sm-12 padd-box">


                    <h2 class="tx col-md-12 col-sm-12 text-center border-design-guia ajustes-design-guia">Casamento</h2>

                    <div class="col-md-12 col-sm-12 padd-box">

                        <section class="bordered ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-noivas.php">
                                <p class="txt-right">Saiba como escolher o vestido de noiva ideal</p>
                            </a>

                             <a href="materia-noivas.php"><img src="img/noivas.jpg" class="img-responsive" alt="noivas">
                            </a>
                        </section>


                        <section class="bordered divisor ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-madrinhas.php">
                                <p class="txt-right">Boca vermelha e olhos neutros: Make para madrinhas</p>
                            </a>

                               <a href="materia-madrinhas.php"><img src="img/makenoivas.jpg" class="img-responsive" alt="cabelos">
                            </a>

                        </section>
                        
                        
                    </div>

                </div>


    


            </section>

         
            
         <section>

                <div class="col-md-6 col-sm-12 padd-box">


                    <h2 class="tx col-md-12 col-sm-12 text-center border-design-guia ajustes-design-guia">Plantão estilo</h2>

                    <div class="col-md-12 col-sm-12 padd-box">

                        <section class="bordered ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-reveillon.php">
                                <p class="txt-right">Réveillon 2016: Marcas trazem estilos que conservam a tradição.</p>
                            </a>

                             <a href="materia-reveillon.php"><img src="img/brancol.jpg" class="img-responsive" alt="Tendencia de moda">
                            </a>
                        </section>


                        <section class="bordered divisor ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-lookdespojado.php">
                                <p class="txt-right">Peças básicas são o caminho para conseguir um look despojado </p>
                            </a>

                               <a href="materia-lookdespojado.php"><img src="img/looktrabalho.jpg" class="img-responsive" alt="look">
                            </a>
                        </section>
                        
                        
                    </div>

                </div>


                   
        


            </section>
 
                  </div>
      

        <?php
        include './includes/footer.php';
        ?> 
        

    

 </div>
  

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
   
</body>

</html>
  