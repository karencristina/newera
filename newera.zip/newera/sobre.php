<!DOCTYPE html>
<html lang="pt-BR">
    
<?php 
$title='Sobre';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        
            
            
        
            
            
          
        <div class="row">

            <article>
            <h1>Nossa Equipe</h1>
                
           
                
                <div class="col-md-8 col-md-push-2 col-sm-12 padd-box">
                    
                   
                     <section class="bordered">
                        
                       <div class="col-md-3 col-sm-3 padd-box">
                         <img src="img/geovane.jpg" class="img-responsive" alt="uma pessoa legal">
                         
                         </div>
                       <div class="col-md-8 col-sm-8 padd-box">
                         
                        <h2 class="title-team">Geovane Moraes</h2>
                        <p>RA:2650831513011</p>   
                        <p class="text-team">Área do site: <a href="./carros.php" class="sob-dest">Carros</a>, <a href="./dicas.php" class="sob-dest">Manutenção</a>, <a href="./games.php" class="sob-dest">Games</a>, <a href="./xbox.php" class="sob-dest">Xbox</a>, <a href="./play.php" class="sob-dest">Play Station</a>, <a href="./normas.php" class="sob-dest">Normas</a>, Designer,Gerente de projeto.</p>
                           <q>Gosto de animes, jogar Yu Gi Oh ,assistir séries, e jogo video game.</q>
                       
                         
                       </div>
                        
 
                   </section>
                    

            
            
                </div>
                
                  
                <div class="col-md-8 col-md-push-2 col-sm-12 padd-box">
                    
                   
                     <section class="bordered">
                        
                       <div class="col-md-3 col-sm-3 padd-box">
                         <img src="img/karen.jpg" class="img-responsive" alt="uma pessoa legal">
                         
                         </div>
                       <div class="col-md-8 col-sm-8 padd-box">
                         
                        <h2 class="title-team">Karen Lara</h2>
                        <p>RA:2650831513015</p>   
                        <p class="text-team">Área do site:<a href="./moda.php" class="sob-dest">Moda</a>, <a href="./tendencias.php" class="sob-dest">Tendências</a>, <a href="./guiadeestilo.php" class="sob-dest">Guia de Estilo</a> wireframes.</p>
                        <q>Gosto de moda,coisas fofas e principalmente animais S2.</q>
                       
                         
                       </div>
                        
 
                   </section>
                    

            
            
                </div>
                
                 <div class="col-md-8 col-md-push-2 col-sm-12 padd-box">
                    
                   
                     <section class="bordered">
                        
                       <div class="col-md-3 col-sm-3 padd-box">
                         <img src="img/luciana.jpg" class="img-responsive" alt="uma pessoa legal">
                         
                         </div>
                       <div class="col-md-8 col-sm-8 padd-box">
                         
                        <h2 class="title-team">Luciana Venâncio</h2>
                        <p>RA:2650831513018</p>   
                        <p class="text-team">Área do site:<a href="./bemestar.php" class="sob-dest">Bem Estar</a>, <a href="./beleza.php" class="sob-dest">Beleza</a>, <a href="./saude.php" class="sob-dest">Saúde</a>, Wireframes.</p>
                           <q>Acho que não gosto de nada....ou melhor, gosto de não gostar de nada.</q>
                       
                         
                       </div>
                        
 
                    </section>
                    

            
            
                </div>
            
                 <div class="col-md-8 col-md-push-2 col-sm-12 padd-box">
                    
                   
                     <section class="bordered">
                        
                       <div class="col-md-3 col-sm-3 padd-box">
                         <img src="img/lancaster.jpg" class="img-responsive" alt="uma pessoa legal">
                         
                         </div>
                       <div class="col-md-8 col-sm-8 padd-box">
                         
                        <h2 class="title-team">Matheus Lancaster</h2>
                        <p>RA:2650831513022</p>   
                        <p class="text-team">Área do site:<a href="./cinema.php" class="sob-dest">Cinema</a>, <a href="./cinemasub.php" class="sob-dest">Filmes</a>, <a href="./series.php" class="sob-dest">Séries</a>, Wireframes e Mapa do Site.</p>
                           <q>Gosto de séries, futebol e sempre que possível jogo ps4.</q>
                       
                         
                       </div>
                        
 
                   </section>
                    

            
            
                </div>
            
                 <div class="col-md-8 col-md-push-2 col-sm-12 padd-box">
                    
                   
                     <section class="bordered">
                        
                       <div class="col-md-3 col-sm-3 padd-box">
                         <img src="img/rony.jpg" class="img-responsive" alt="uma pessoa legal">
                         
                         </div>
                       <div class="col-md-8 col-sm-8 padd-box">
                         
                        <h2 class="title-team">Rony Nogueira</h2>
                        <p>RA:2650831513029</p>   
                        <p class="text-team">Área do site:<a href="./index.php" class="sob-dest">Home</a>, <a href="./tecnologia.php" class="sob-dest">Tecnologia</a>, <a href="./celular.php" class="sob-dest">Celular</a>, <a href="./pc.php" class="sob-dest">PC</a>, <a href="./contato.php" class="sob-dest">Contato</a>, <a href="./sobre.php" class="sob-dest">Sobre</a>.</p>
                           <q>Eu?...gosto de jogar magic com os amigos, jogar conversa fora e rir muito.</q>
                       
                         
                       </div>
                        
 
                   </section>
                    

            
            
                </div>
            
            
            </article>
        
        </div>
        
               
            
       <?php
        include './includes/footer.php';
        ?> 

  
           

        </div>
     

 




    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
</body>

</html>
  

