
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

            </div>

            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="./index.php" title="Home">Home</a>
                    </li>
                    <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Carros <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="./carros.php">Notícias</a></li>
                  <li><a href="./dicas.php">Manutenção e Dicas</a></li>
                 
                </ul>
              </li>
                    
                 <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Games <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="./games.php">Destaques</a></li>
                  <li><a href="./xbox.php">Xbox</a></li>
                  <li><a href="./play.php">Playstation</a></li>
                </ul>
               </li>  
                    
                         
                 <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Cinema <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="./cinema.php">Destaques</a></li>
                  <li><a href="./cinemasub.php">Filmes</a></li>
                  <li><a href="./series.php">Séries</a></li>
                </ul>
               </li>  
                    
                      <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Tecnologia <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="./tecnologia.php">Destaques</a></li>
                  <li><a href="celular.php">Celular</a></li>
                  <li><a href="pc.php">PC</a></li>
                </ul>
               </li>  
                   
                      <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Moda <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="./moda.php">Destaques</a></li>
                  <li><a href="./tendencias.php">Tendências</a></li>
                  <li><a href="./guiadeestilo.php">Guia de Estilo</a></li>
                </ul>
               </li>  
                    
                         <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bem estar <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="./bemestar.php">Destaques</a></li>
                  <li><a href="./beleza.php">Beleza</a></li>
                  <li><a href="saude.php">Saúde</a></li>
                </ul>
               </li>  
                    <li><a href="./sobre.php"  title="Sobre Nós">Sobre Nós</a>
                    </li>
                     <li><a href="./normas.php"  title="normas">Normas</a>
                    </li>
                 
                     <li><a href="./contato.php"  title="Contato">Contato</a>
                    </li>
                </ul>
            </div>
 
        </div>
    </nav>


