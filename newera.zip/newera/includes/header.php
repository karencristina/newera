<div class="row">

            <header>

                <div class="col-md-2 padd-box">

                 <a href="./index.php"><img src="img/Logo.png" class="img-responsive" alt="New Era noticias"></a>    

                </div>

            </header>

        </div>