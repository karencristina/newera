       <div class="row">
      


            <footer>

                 <div class="col-md-2 padd-box">

                   <a href="./index.php"><img src="img/Logo.png" id="logo-f" class="img-responsive" alt="New Era noticias"></a>  

                </div>

                <div class="col-md-10 padd-box hidden-xs ">

                    <ul class="list-inline" id="menu-footer">

                        <li><a href="index.php">Home</a></li>
                        <li><a href="carros.php">Carros</a></li>
                        <li><a href="games.php">Games</a></li>
                        <li><a href="cinema.php">Cinema</a></li>
                        <li><a href="tecnologia.php">Tecnologia</a></li>
                        <li><a href="moda.php">Moda</a></li>
                        <li><a href="bemestar.php">Bem Estar</a></li>
                        <li><a href="sobre.php">Sobre Nós</a></li>
                        <li><a href="normas.php">Normas</a></li>
                        <li><a href="contato.php">Contato</a></li>
                        

                    </ul>


                </div>

            </footer>


        </div>

   