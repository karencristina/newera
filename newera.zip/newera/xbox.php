<!DOCTYPE html>
<html lang="pt-BR">
    
    <?php
$title='Xbox';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">

            
         
            
            <article>
                

                <div class="art-xbox col-md-7 col-sm-12   padd-box">

                  <a href="materia-halo.php"><img src="img/halo-xbox.jpg" class="img-responsive" alt="Halo"></a>

                   






                </div>
             

                 <div class="art-xbox col-md-5 col-sm-12 padd-box">

                    <a href="materia-halo.php"><h1 class="titulo-games">Jogamos: Halo 5 impressiona com mecânicas, mas história deixa a desejar</h1></a>

                  <h2 class="chamada">A história é fraca, mas garante novo herói e empolga com missões incríveis.
'Halo' se moderniza e fica mais ágil com novas habilidades dos soldados.</h2>






                </div>
                
                
              
      

            </article>



        </div>
        
        
        
        
        
        
        
        
        
        
 


         
   
      
        <div class="row">
            
                 <section>      
            
         <section>
            

             
             
             <section>

                <div class="col-md-6 col-sm-12  padd-box">


                 <h2 class="tx col-md-12 col-sm-12 text-center border-gamesxl pre-gemes-xl">Análises</h2>

                   
                    <div class="col-md-12 col-sm-12 padd-box">

                        <section class="border-guio ">

                            <a href="xbox.php"><h2 class="title-h2-gms color-games ">Xbox</h2></a>

                            <a href="materia-the-witcher.php">
                                <p class="tcm txt-gms">Review de The Witcher 3: Wild Hunt para XONE de GameTV</p>
                            </a>

                            <a href="materia-the-witcher.php"><img src="img/witcher-pq.jpg" class="img-responsive" alt="The Witcher"></a>


                        </section>


                        <section class="border-guio">

                            <a href="xbox.php"><h2 class="title-h2-gms color-games ">Xbox</h2></a>

                            <a href="materia-gears.php">
                                <p class="tcm txt-gms">Review de Gears of War: Ultimate Edition para XONE de IGN</p>
                            </a>

                            <a href="materia-gears.php"><img src="img/gears-pq.jpg" class="img-responsive" alt="Marcus"></a>

                        </section>
                        
                         <section class="border-guio">

                            <a href="xbox.php"><h2 class="title-h2-gms color-games ">Xbox</h2></a>

                            <a href="materia-evolve.php">
                                <p class="tcm txt-gms">Review de Evolve para XONE de IGN</p>
                            </a>

                            <a href="materia-evolve.php"><img src="img/evolve-pq.jpg" class="img-responsive" alt="Monstro atacando personagem"></a>

                        </section>
                        
                        
           

                </div>

                           
                </div>


            </section>
            </section>
            
    
        
        
        
        
        
        
        

             
       
               <section>

                <div class="col-md-3 col-sm-12  padd-box">


                   <h2 class="tx col-md-12 col-sm-12 text-center border-gamesxl pre-gemes-xl">Notícias</h2>

                   

                        <div class="col-md-12 col-sm-12  padd-box ">

                    <section class="border-guio">
  <a href="materia-xbox-elite.php"><img src="img/xone.jpg" class="img-responsive" alt="..."></a>
                       <a href="materia-xbox-elite.php"><p class="txt-games">Xbox One Elite chega ao Brasil em dezembro</p></a>

                    

                    </section>
                    
                   <section class="border-guio">
  <a href="materia-fallout.php"><img src="img/fallout.jpg" class="img-responsive" alt="Fallout 4"></a>

              <a href="materia-fallout.php"><p class="txt-games">Fallout 4 irá rodar 900p no X-One e 1080p no playstation</p></a>   

                    </section>
                    
                

                </div>

                           
                </div>


            </section>
             
             
                  
           <section>

                <div class="col-md-3 col-sm-12 padd-box">


                    <h2 class="tx col-md-12 col-sm-12 text-center border-gamesxl pre-gemes-xl">Lançamentos</h2>

                    <div class="col-md-12 col-sm-12 padd-box">
<div class="panel panel-default">
  

  <ul class="list-group">
    <li class="list-group-item">17 Nov, 2015 |
Star Wars: Battlefront</li>
      <li class="list-group-item">01 Dez, 2015 Just Cause 3</li>
      
    <li class="list-group-item">01 Dez, 2015 | Rainbow Six: Siege </li>
    <li class="list-group-item">09 Fev, 2016 | Battleborn</li>
      
    <li class="list-group-item">23 Fev, 2016 | Far Cry Primal </li> 
      
      <li class="list-group-item">05 Mar, 2016 | Quantum Break </li> 
      
      <li class="list-group-item">08 Mar, 2016 | Tom Clancy's The Division </li> 
      
      <li class="list-group-item">11 Mar, 2016 | Hitman </li> 
      
  
    
  </ul>
</div>         
                        
           

                </div>
               </div>

            </section>
             
                 
             
                     
                     
             
            
            </section> 
          
          
           
            
            
        </div>
        
        
        
        
        
         <div class="lara row">

            
         
            
            <section>
               
                    
        <div class="art-xbox col-md-12 col-sm-12 col-xm-12   padd-box">

                  <a href="materia-tomb.php"><img src="img/lara-play.jpg" class="img-responsive" alt="Soldado"></a>
                   <a href="materia-tomb.php"><h1 class="col-sm-6 title-h1-t  hidden-xs">Rise of the Tomb Raider: confira a análise</h1></a>
                 
            <a href="materia-tomb.php"><h1 class="titulo-games-p visible-xs">Rise of the Tomb Raider: confira a análise</h1></a>
                   






                </div>
             

                
                
            </section>

                
                
           
                


        </div>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <div class="lpx row">
       
            
            
            
            
             <section class="vs">
               
  <h2 class="txx col-md-12 col-sm-12 text-center border-gamesxl pre-gemes-xl">Vídeos</h2>

<h4>Os primeiros 30 minutos de Just Cause 3 no Xbox One</h4>

<div class="lst">
 
    <div class="col-sm-6">
   
     
<div class="embed-responsive embed-responsive-16by9">
   <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/oFKeUCxN1Ws"></iframe>
</div>
    </div>
      
      <div class="col-sm-6">
          
            <h1 class="titulo-games">Just Cause 3</h1>

                  <h2 class="chamada-d">Just Cause 3 é um jogo de ação-aventura produzido e publicado pela Square Enix, sendo é a sequência da saga anterior </h2>
      
      </div>
    

</div>
               
          
            
            
            </section>
            
        </div>
    


 <?php
        include './includes/footer.php';
        ?> 

    </div>

    
 

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
       
</body>

</html>