<!DOCTYPE html>
<html lang="pt-BR">
    
    <?php
$title='Series';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">

 
         
            <div class="col-md-12 col-sm-12 padd-box"> 
         
            </div>
       
            <h1 class="blocoseries col-md-12 col-sm-12 padd-box">Séries </h1>
            
            <section>
       
                <div class="col-md-4 col-sm-4 padd-box">


                    <section class="bordered seriesmargem">

                        <a href="materia-flash1.php">    <img src="img/flash_banner.jpg__932x545_q85_subsampling-2.jpg" class="img-responsive" alt="..."> </a>
                        <a href="materia-flash1.php"><h2 class="txt-notice text-center"> The Flash: Segunda temporada terá nova forma de apresentar vilões.
                            </h2></a>

                    </section>


                </div>


                <div class="col-md-4 col-sm-4 padd-box">


                    <section class="bordered seriesmargem">

                        <a href="materia-marvel.php"> <img src="img/xman.jpg" class="img-responsive" alt="..."> </a>
                        <a href="materia-marvel.php"><h2 class="txt-notice text-center">Marvel e FOX anunciam novas séries baseadas no universo X-man </h2></a>

                    </section>


                </div>

 
                <div class="col-md-4 col-sm-4 padd-box ">


                    <section class="bordered seriesmargem">

                        <a href="materia-gotham.php">  <img src="./img/Ghotam3.jpg" class="img-responsive" alt="..."> </a>
                        <a href="materia-gotham.php"><h2 class="txt-notice text-center">Gotham: Série ficará 3 meses fora do ar devido as férias
                        </h2></a>

                    </section>


                </div>

              

                
            </section>




        </div>
        
        
        <div class="row">
            
            
         
            

                   
            
        
            

            <section>

                <div class="col-md-6 col-sm-12 padd-box">


                    <h2 class=" col-md-12 col-sm-12 text-center border-jessica">Jessica Jones</h2>

                    <div class="col-md-12 col-sm-12 padd-box">

                        <section class="bordered ">

                           

                            

                         <a href="materia-jessicajones.php">   <img  src="img/jessica-jones.jpg" class="img-responsive" alt="..."></a>  


                        </section>


                      
                        
                        
           

                </div>
                </div>

                    </section>
            



            

          <section>
                
                <div class="col-md-6 col-sm-12 padd-box">
                    <h2 class="text-center  border-legends">Legends of Tomorrow</h2>
                <div class="col-md-12 col-sm-12 padd-box">


                    <section class="bordered">

                        
                     <a href="materia-legendsoftomorrow.php">   <img src="img/legendsoftomorrow.jpg" class="img-responsive" alt="...">
                      </a>

                    </section>
                    
                
                </div>
            
                    </div>
            
            </section>

              
        </div>
            
        
        
        
        
            
                
                
            
    
        <div class="row">
            
            

        
        
               
        <div class="row">
            
            
         
            

                   
            
        
            

            <section>

                <div class="col-md-6 col-sm-12 padd-box">


                    <h2 class=" col-md-12 col-sm-12 text-center  border-big">The Big Bang Teory</h2>

                    <div class="col-md-12 col-sm-12 padd-box">

                        <section class="bordered ">

                         
                            <a href="materia-thebigbang.php">
                            <img src="img/thebingbang.jpg" class="img-responsive" alt="...">

                            </a>
                        </section>


                    
                        
    
                </div>
                </div>

                    </section>
            



            

          <section>
                
                <div class="col-md-6 col-sm-12 padd-box">
                    <h2 class="text-center border-fear">Fear The Walking Dead</h2>
                <div class="col-md-12 col-sm-12 padd-box">


                    <section class="bordered">
                        <a href="materia-fear.php">
                        <img src="img/fear.jpg" class="img-responsive" alt="...">
                        </a>

                    </section>
                    
                
                </div>
            
                    </div>
            
            </section>

              
        </div>
            
        
        
        
        
            
        
            


        
        
        
        
        
        <div class="row">
      


        <?php
        include './includes/footer.php';
        ?> 

          
        </div>

    </div>


    <script src="./js/jquery-1.11.0.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    </div>
</body>
</html>