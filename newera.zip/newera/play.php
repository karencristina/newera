<!DOCTYPE html>
<html lang="pt-BR">
    
    <?php
$title='Playstation';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">

            
         
            
            <article>
               
                    
        <div class="art-xbox col-md-12 col-sm-12 col-xm-12   padd-box">

                  <a href="materia-blackops.php"><img src="img/the-last.jpg" class="img-responsive" alt="Soldado"></a>
                   <a href="materia-blackops.php"><h1 class="col-sm-6 title-h1-p  hidden-xs">Call of Duty: Black Ops III é lançado</h1></a>
                 
            <a href="materia-blackops.php"><h1 class="titulo-games-p borda-mat visible-xs">Call of Duty: Black Ops III é lançado</h1></a>
                   






                </div>
             

                
                
            </article>

                
                
           
                


        </div>
            
            
            
            
            
            
            
            
            
            
 

                 
                 
                  
                 
                 
                 
                 
        <div class="row">
            
                 <section>      
            
         <section>
            

             
             
             <section>

                <div class="col-md-6 col-sm-12  padd-box">


                 <h2 class="tx col-md-12 col-sm-12 text-center border-gamesge-l pre-gemes-l">Notícias</h2>

                   
                    <div class="col-md-12 col-sm-12 padd-box">
                        
                        
                        
                         <section class="play-notice">

                          <a href="materia-thelast.php"><img src="img/last.jpg" class="img-responsive" alt="personagens do jogo"></a>

                             <a href="materia-thelast.php"><h2 class="txt-notice-p text-center">The Last of Us 2 pode estar em produção</h2></a>
                            
                        </section>
                        
                        
                         <section class="play-notice">

                          <a href="materia-need.php"><img src="img/need-play.jpg" class="img-responsive" alt="carro do jogo"></a>

                             <a href="materia-need.php"><h2 class="txt-notice-p text-center">Need for Speed terá várias DLCs, todas gratuitas</h2></a>
                            
                        </section>
                        
                        
                        
                        <section class="play-notice">

                          <a href="materia-uncharted.php"><img src="img/uncharted.jpg" class="img-responsive" alt="Drake na moto"></a>

                             <a href="materia-uncharted.php"><h2 class="txt-notice-p text-center">Uncharted 4: os desenvolvedores são só elogios à obra</h2></a>
                            
                        </section>
                        
                        
                        

                    </div>
                    
                    
                    
                    
                    

                           
                </div>


            </section>
            </section>
            
    
        
                            </section>

                     
                     
                     
                     
                     
              
                     
                     <section>

                <div class="col-md-6 col-sm-12  padd-box">


                   <h2 class="tx col-md-12 col-sm-12 text-center border-gamesge-l pre-gemes-l">Destaque</h2>
                        
                          <div class="col-md-12 col-sm-12 padd-box">

                      <section class="border-guio-p ">
                           <a href="play.php"><h2 class="title-h2-gms-p color-games ">Playstation</h2></a>

                            <a href="materia-playstation-ex.php">
                                <p class="tcm txt-gms">Revelados jogos disponíveis na PlayStation Experience</p>
                            </a>

                            <img src="img/p-test.jpg" class="img-responsive" alt="Logo Playstation">


                        </section>
                              
                               <section class="border-guio-p ">

                             <a href="play.php"><h2 class="title-h2-gms-p color-games ">Playstation</h2></a>

                            <a href="materia-naruto.php">
                                <p class="tcm txt-gms">Naruto Ultimate Ninja 4 Transformação de Kaguya</p>
                            </a>

                            <img src="img/naruto-md.jpg" class="img-responsive" alt="Naruto">


                        </section>
                              
                              
                               <section class="border-guio-p ">

                           <a href="play.php"><h2 class="title-h2-gms-p color-games ">Playstation</h2></a>

                            <a href="materia-hitman.php">
                                <p class="tcm txt-gms">Beta de Hitman estará disponível no PS4 em Fevereiro</p>
                            </a>

                            <img src="img/hitman-pq.jpg" class="img-responsive" alt="Assassino 47">


                        </section>
                              
                              
                              
                              
                              
                    </div>
                   
                    
                    
                       
        
        
     

             
       
               <section>

                <div class="col-md-6 col-sm-12  padd-box">


                   <h2 class="tx col-md-12 col-sm-12 text-center border-gamesge-l pre-gemes-l">Saiba mais</h2>

                     <a href="materia-play-network.php"><img src="img/play-net.jpg" class="img-responsive" alt="playstation Network"></a>
                 
                      
                    
                    
                    
                    
                 
                      

                           
                </div>

                   
                   
                   
                   
                   

            </section>
                    
                    
                    
                    
                    
                                   <section>

                <div class="col-md-6 col-sm-12  padd-box">


                  

                     
                  <div class="icon col-md-12 col-sm-12 col-xs-12 padd-box">
                        
                        
                        
                        
                        <section class="play-notice-ef">

                        <a href="#"><img src="img/blood.jpg" class="img-responsive hidden-xs  hidden-sm" alt="icon"></a>
                            
                            <a href="#"><img src="img/ad-blood.jpg" class="img-responsive  visible-sm visible-xs" alt="icon"></a>

                             
                            
                        </section>
                        
                        
                        

                    </div>
                    
                                
                    
                    
                    
                    
                 
                      

                           
                </div>

                   
                   
                   
                   
                   

            </section>
                     
                      

                           
                </div>


            </section>
                     
                                 </div>
                     
                     
                     
                     
                     
                     
                     
                     
                    
                     
                     
                     
                     
                     
                     
                     
                     
                       
                     
                     
                     
                     
                     
             
             
                  
             
            
     
          
          
           
            
            
    
                 
                 
                 
                 
                 
                 
                 
        
            
            
            
            
            
            
            
            
    <div class="lp row">
       
              <section class="np">
               <h2 class="txi col-md-12 col-sm-12 text-center border-gamesge-l pre-gemes-l">Vídeos</h2>
                 


<div class="vps">

    <div class="col-sm-6">
   
     
<div class="embed-responsive embed-responsive-16by9">
   <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/N2V2Ex-4Xsk"></iframe>
</div>
    </div>
      
     
    

</div>
               
          
            
            
            </section>
            
            
            
            
            
        </div>
        
        
         
   
      
  
  


 <?php
        include './includes/footer.php';
        ?> 

    </div>

    
   

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
       
</body>

</html>
  

