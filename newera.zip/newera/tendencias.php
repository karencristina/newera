<!DOCTYPE html>
<html lang="pt-BR">
    
<?php 
$title='Moda';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">


            
            
            <article>

                <div class="text-moda col-md-6 col-sm-6   padd-box">
                    

                    
                    <a href="materia-pretoebranco.php"><img src="img/pretoebranco.jpg" class="img-responsive" alt="Semana moda">

                    <a href="materia-pretoebranco.php"><h1 class=" title-h1-carros blackpainel-tr-karen ">Preto e branco: Um dos estilos mais elegantes da moda </h1></a>






                </div>
             

                <div class="text-moda col-md-6 col-sm-6  padd-box ">

                  
                    <a href="materia-quartzo.php"><img src="img/rosa_quartzo.jpg" class="img-responsive" alt="cores">

                    <a href="materia-quartzo.php"><h1 class="title-h1-carros blackpainel-tr-karen">Rosa quartzo é eleita pela pantone a cor do verão 2016  </h1></a>




                </div>
      

            </article>
                 
                    
        </div>
 
 <div class="row">

       
                                    
<h2 class="tx col-md-12 col-sm-12 text-center border-design-tendencia ajustes-design-tendencia">Estilos em alta</h2>
                    <div class="text-moda col-md-4 col-sm-4   padd-box">

                    
                    <a href="materia-gravida.php"><img src="img/gravidas.jpg" class="img-responsive" alt="cores"></a>

                    <a href="materia-gravida.php"><h1 class=" title-h1-carros blackpainel-tr-karen-tendencia ">Looks ideiais para se manter linda durante a gravidez </h1></a>




                        

                </div>
             

                <div class="text-moda col-md-4 col-sm-4  padd-box ">
                    

                  
                    <a href="materia-malhas.php"><img src="img/veraopreto.jpg" class="img-responsive" alt="cores">
                    </a>

                    <a href="materia-malhas.php"><h1 class="title-h1-carros blackpainel-tr-karen-tendencia">Sobreposições de malhas assimétricas são grandes apostas </h1></a>




                </div>
      
    <div class="text-moda col-md-4 col-sm-4  padd-box ">

                  
        <a href="materia-make.php"><img src="img/blush.jpg" class="img-responsive" alt="cores"></a>

                    <a href="materia-make.php"><h1 class="title-h1-carros blackpainel-tr-karen-tendencia">Maquiagem verão 2016: Tons com blush e batom nude</h1></a>

        
       
                    </div>
                 

                </div> 
                        
     <div class="row">     
   

<section>

                <div class="col-md-6 col-sm-12 padd-box">


                    <h2 class="tx col-md-12 col-sm-12 text-center  border-design-tendencia ajustes-design-tendencia">Tapete vermelho</h2>

                    <div class="col-md-12 col-sm-12 padd-box">

                        <section class="bordered ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-vestidos.php">
                                <p class="txt-right">Os modelos de vestidos ícones do tapete vermelho</p>
                            </a>

                             <a href="materia-vestidos.php"><img src="img/vestido.jpg" class="img-responsive" alt="Tendencia de moda">
                            </a>

                        </section>


                        <section class="bordered divisor ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-modelo.php">
                                <p class="txt-right">Fendas poderosas fazem sucesso entre as famosas</p>
                            </a>

                               <a href="materia-modelo.php"><img src="img/modelos.jpg" class="img-responsive" alt="modelos">
                            </a>

                        </section>
                        
                        
                    </div>

                </div>





            </section>

          <section>

                <div class="col-md-6 col-sm-12 padd-box">


                    <h2 class="tx col-md-12 col-sm-12 text-center  border-design-tendencia ajustes-design-tendencia">Desfiles</h2>

                    <div class="col-md-12 col-sm-12 padd-box">

                        <section class="bordered ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-floresetransparencia.php">
                                <p class="txt-right">Louis Vuitton traz flores e transparência para a passarela</p>
                            </a>

                             <a href="materia-floresetransparencia.php"><img src="img/transparencia.jpg" class="img-responsive" alt="Tendencia de moda">
                            </a>

                        </section>


                        <section class="bordered divisor ">

                            <a href="moda.php"><h2 class="title-h2 color-moda ">Moda</h2></a>

                            <a href="materia-estilos.php">
                                <p class="txt-right">Cartela de cores e estilos ecléticos marcaram a semana da moda em Paris</p>
                            </a>
                            

                               <a href="materia-estilos.php"><img src="img/estilo.jpg" class="img-responsive" alt="estilo">

                            </a>
                        </section>
                
                        
                    </div>

                </div>


    </section>


           

        
            
            

            </div>
    

        <?php
        include './includes/footer.php';
        ?> 
        

    

 </div>
  

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
   
</body>

</html>
  