<!DOCTYPE html>
<html lang="pt-BR">
    
<?php 
$title='PC';
include './includes/head.php'; ?>

 
<body>
    

    <div class="container">

       <?php
        include './includes/nav.php';
        ?> 
      
      <?php 
        include './includes/header.php';
       ?>


        <div class="row">


            <article>

                <div class="col-md-7  padd-box">

                    <a href="./materia-window.php"><img src="img/win10.jpg" class="img-responsive" alt="microsoft admite ter tentado instalar windows 10 a força"></a>

                    <a href="./materia-window.php"><h1 class="title-pc painel-pc">Microsoft adimite ter tentado instalar Windows 10 a força</h1></a>






                </div>
             

                <div class="col-md-5   padd-box ">

                   <section>
                    <h2 class="text-center topzero-pc border-pc color-pc text-ajustepc tx">Destaque do dia</h2>
                      <section class="bordered" id="boxpc6">

                      <a href="./materia-appleafirma.php"><img src="img/appletim.jpg" class="img-responsive" alt="apple afirma ser melhor que outras empresas"></a> 
                        <a href="./materia-appleafirma.php"><h2 class="txt-noticepc text-center">Apple afirma "Nossos clientes são mais  felizes" entenda o motivo</h2></a>

                </section>
                    
                
                    </section>
                     
                

                </div>
                
                
                 
                
              

            </article>



        </div>
 

 
        <div class="row">
        
       <div class="col-md-12 padd-box">
            
             
           <section>
              
            <h2 class="text-center color-pc border-pc text-ajustepc tx">Mais Lidas</h2>
             
               
            <div class="col-md-4 col-sm-4 padd-box">
               
                <section class="bordered">

                   <a href="./materia-macbook.php"> <img src="img/Apple.jpg" class="img-responsive" alt="novo mackboo pró"></a>    
                        <a href="./materia-macbook.php"><h2 class="txt-notice text-center">Novo Mac Book Pró vai te surpreender</h2></a>

                </section>
            
            </div>
               
            
             <div class="col-md-4 col-sm-4 padd-box">
               
               <section class="bordered">

                    <a href="./materia-nvidiamelhor.php"><img src="img/nvidia.jpg" class="img-responsive" alt="nvidida diz ser melhor que concorrentes"></a>    
                        <a href="./materia-nvidiamelhor.php"><h2 class="txt-notice text-center">Nvidia fala "Somos melhores que outros"</h2></a>

                    </section>
            
            </div>   
               
               
                <div class="col-md-4 col-sm-4 padd-box">
                    
                    <section class="bordered">

                   <a href="./materia-intelprocessador.php"><img src="img/intel.jpg" class="img-responsive" alt="intel lança novos processadores"></a>     
                        <a href="./materia-intelprocessador.php"><h2 class="txt-notice text-center">Intel inicia vendas de novo processador </h2></a>

                    </section>
            
            </div>   
              
          
                  


                 
            
          </section>
        
        
        
        </div>
        
           
         
            
        </div> 
         
        
        
        <div class="row">

            <section>

                <h2 class="text-center color-pc border-pc text-ajustepc tx">Destaque da Semana</h2>

                
                  <div class="col-md-6 col-sm-6 padd-box">


                    <section class="bordered">

                    <a href="./materia-dell.php"><img src="img/delxps.jpg" class="img-responsive" alt="novo dell xps 13"></a>    
                        <a href="./materia-dell.php"><h2 class="txt-notice text-center">Dell XPS 13 chega com processador Intel Skylake</h2></a>

                    </section>


                </div>
                
                



               
                
                  <div class="col-md-6 col-sm-6 padd-box">


                    <section class="bordered">

                      <a href="./materia-amd.php"><img src="img/amd.jpg" class="img-responsive" alt="amd revela nova linha de processadores"></a>  
                        <a href="./materia-amd.php"><h2 class="txt-notice text-center">AMD revela sua nova linha de processadores Caterpillar</h2></a>

                    </section>


                </div>

 
            </section>
    


        </div>
        
    


        <?php
        include './includes/footer.php';
        ?> 

    </div>




    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
</body>

</html>
  

